﻿// CodeGear C++Builder
// Copyright (c) 1995, 2016 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uTPLb_SVN_Keywords.pas' rev: 32.00 (Windows)

#ifndef Utplb_svn_keywordsHPP
#define Utplb_svn_keywordsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>

//-- user supplied -----------------------------------------------------------

namespace Utplb_svn_keywords
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE System::UnicodeString TPLB3Runtime_SVN_Keyword_Date;
extern DELPHI_PACKAGE System::UnicodeString TPLB3Runtime_SVN_Keyword_Revision;
extern DELPHI_PACKAGE System::UnicodeString TPLB3Runtime_SVN_Keyword_Author;
extern DELPHI_PACKAGE System::UnicodeString TPLB3Runtime_SVN_Keyword_HeadURL;
extern DELPHI_PACKAGE System::UnicodeString TPLB3Runtime_SVN_Keyword_Id;
extern DELPHI_PACKAGE int __fastcall TPLB3Runtime_SVN_Revision(void);
}	/* namespace Utplb_svn_keywords */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UTPLB_SVN_KEYWORDS)
using namespace Utplb_svn_keywords;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Utplb_svn_keywordsHPP
